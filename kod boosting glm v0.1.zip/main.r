# =========================================================================
# =========================================================================
#                         Boosting GLM 
# =========================================================================
# =========================================================================


# INIT
setwd("//e75a0679/sakta/UTV/SU/Program/Analys/Boosting GLM/Boosting-GLM")
source("load_packages.r")
load_packages(updateR = FALSE)
 

# Output parameters --------------------------------------------------
suffix <- "CAS"
date <- "20220722"
REAL_data <- FALSE

new_models <- FALSE
new_univar_effects <- FALSE
save <- FALSE

plot_folder <- paste("Plottar/",suffix,"_",date, sep="")
dir.create(plot_folder)
n_sim <- 650000


# Algo parameters ---------------------------------------------------------

plot_during_algo <- FALSE
n_trees_mu <- 1000
tree_depth_mu <- 2
learning_rate_mu <- 0.025

# Factors of interest

if (REAL_data== TRUE){
facts <- c("BOYTA", 
           "Bolag" , 
           "Fast_alder" , 
           "Byggnadstyp" , 
           "Brevobjekt" , 
           "Alder" )
 
}else{
  facts <- c("Area"	, 
             "VehPower"	, 
             "VehAge" ,	
             "DrivAge" , 
             "VehBrand", 
             "VehGas",
             "Density", 
             "Region", 
             "BonusMalus" )
}

# Data ----------------------------------------------------------------

df <- list()
train_frac <- 0.8
cal_frac <- 0.3 # Of the training data, how much for calibration of marginal effects?
 

### IMPORT CAS ###
if (REAL_data == FALSE){
  library(CASdatasets)
  data("freMTPL2freq")
  
  data_input <- freMTPL2freq 
  
  data_idx <- sample(c(1:dim(data_input)[1] ), size = n_sim, replace = FALSE)
  df$all <- as.data.frame(data_input[data_idx,])
  
  
  # Corrections according to Schelldorfer and W�thrich (2019)
   df$all$ClaimNb <-  pmin( df$all$ClaimNb,4)
   df$all$Exposure <- pmin( df$all$Exposure,1) 
  
  
  # Naming to fit algo
  colnames( df$all)[2] <- "freq"
  colnames( df$all)[3] <- "dur"
  
  # Factors
   df$all$Area <- as.factor( df$all$Area)
   df$all$VehBrand  <- as.factor( df$all$VehBrand)
   df$all$VehGas    <- as.factor( df$all$VehGas)
   df$all$Region    <- as.factor( df$all$Region)
  
  # Correcting n
   df$all$freq <- as.numeric( df$all$freq)
  
  # Data splits
  n_obs <-  df$all$freq[1:n_sim]
  
  
  df$train <- df$all[1:(n_sim*train_frac*(1-cal_frac)), ]
  df$cal <- df$all[(n_sim*train_frac*(1-cal_frac)+1):(n_sim*train_frac), ]
  df$test <- df$all[(n_sim*train_frac +1):n_sim, ]
  
  
  } 

### IMPORT REAL ###
if (REAL_data == TRUE){
  source("//e75a0679/sakta/UTV/SU/Program/Analys/Pricing_ML/import_och_tvatt.r")
  library("haven")
  data_input <- import_och_tvatt("//e75a0679/sakta/UTV/SU/DATA/Tariffanalysdata/df_vb_alla_skador_20170101.sas7bdat",divtest="N")[[3]]
  
  # Variable selction gross
  data_input <- data_input %>% dplyr::select(c(freq,BOYTA, Bolag , Fast_alder , Byggnadstyp , Brevobjekt , Alder, dur))
  
  data_idx <- sample(c(1:dim(data_input)[1] ), size = n_sim, replace = FALSE)
  
  df$all <- as.data.frame(data_input[data_idx,])
  
  # factors 
  df$all$Bolag <- as.factor(df$all$Bolag)
  df$all$Byggnadstyp <- as.factor(df$all$Byggnadstyp)
  df$all$Brevobjekt <- as.factor(df$all$Brevobjekt)
  
  df$train <- df$all[1:(n_sim*train_frac*(1-cal_frac)), ]
  df$cal <- df$all[(n_sim*train_frac*(1-cal_frac)+1):(n_sim*train_frac), ]
  df$test <- df$all[(n_sim*train_frac +1):n_sim, ]
  
} 




# Helpfunctions -----------------------------------------------------------

# Deviance loss
deviance <- function(pred_mu, pred_phi=NULL, y, res){
  
  # Init
  dev <- rep(0,length(y))
  
  # Deviance calculations
  for (i in 1:length(y)){
    if (y[i] == 0){
      dev[i] <- 2*pred_mu[i]
    }
    else {
      dev[i] <- 2*(pred_mu[i] - y[i]  +  y[i]  * log(y[i]/pred_mu[i])) 
    }
  }
  
  # Scaling deviance if wanted
  if (!is.null(pred_phi)) {
    #print("Scaled deviance")
    
    dev <- dev / pred_phi
  } else {
    #print("Unscaled deviance")
  }
  
  if (res==TRUE){
    return(dev)
  }
  else{
    return(sum(dev))
  }
  
}


# Helpvariables -----------------------------------------------------------

num_facts <-  colnames(df$test)[sapply(df$test,class) %in% c("numeric","integer")]
num_facts <- num_facts[!num_facts %in% c("freq","dur","IDpol")]
cat_facts <-  colnames(df$test)[sapply(df$test,class) =="factor" ] 



# ======================================================================
                           ## MODELS ##
# ======================================================================
if (new_models == TRUE){ 
  # INIT and modeling parameters
  
  models <- list()
  pred <- list()
  boosting_df <- list()
  
  
  if (REAL_data == FALSE){
  # MU
  model.freq_gbm.ref <- formula(freq ~  Area	+ 
                                    VehPower	+ 
                                    VehAge +	
                                    DrivAge + 
                                    VehBrand+ 	
                                    VehGas	+
                                    Density+ 	
                                    Region+ 
                                    BonusMalus   +
                                    offset(log(dur)))
  
  
  model.freq_glm.tariff <- formula( freq ~  Area+ 
                               VehPower	+ 
                               VehAge +
                               DrivAge + 
                               VehBrand+ 
                               BonusMalus +	
                               VehGas	+ 
                               Density+ 
                               Region )
  
  
  model.freq_gbm.boost <- formula( freq ~  Area	+ 
                                   VehPower	+ 
                                   VehAge +
                                   DrivAge + 
                                   VehBrand+ 
                                   BonusMalus +	
                                   VehGas	+ 
                                   Density+ 
                                   Region + 
                                   offset(log(init_pred))) # Note that the original predictor (init_pred) contain duration as offset hence not needed here
  
  }
  
  
  if (REAL_data == TRUE){
  # MU
  model.freq_glm.tariff <- formula( freq ~  BOYTA + 
                                      Bolag + 
                                      Fast_alder + 
                                      Byggnadstyp + 
                                      Brevobjekt +
                                      Alder)
  
  model.freq_gbm.ref <- formula( freq ~ BOYTA + 
                                   Bolag + 
                                   Fast_alder + 
                                   Byggnadstyp + 
                                   Brevobjekt + 
                                   Alder  + 
                                   offset(log(dur)))
  
  model.freq_gbm.boost <- formula( freq ~ BOYTA + 
                                     Bolag +
                                     Fast_alder +
                                     Byggnadstyp +
                                     Brevobjekt +
                                     Alder  +  
                                     offset(log(init_pred))) # Note that the original predictor (init_pred) contain duration as offset hence not needed here

  
  }
  # ======================================================================
  ## Existing tariff ##
  # ======================================================================
   # INIT - Import existing tariff --------------------------------------------
  
  # Note: In this case, a simple GLM-structure exemplifies the tariff to be boosted
  
  models$glm_init  <- glm(model.freq_glm.tariff, 
                          data = df$train,
                          offset = log(dur),
                          family = quasipoisson(link = "log"))
  
  summary(models$glm_init)
  
  # INIT - Tariff predictions -----------------------------------------------
  
  # Note: IF original tariff model is not in glm()-form, a scoring procedure that maps tariff input to policy predictions (e.g. tabular -> mu(x_i) )
  
  pred$train$init <- predict.glm(object = models$glm_init, 
                                 newdata = df$train , 
                                 type = "response") 
  
  
  pred$cal$init <- predict.glm(object = models$glm_init, 
                                newdata = df$cal , 
                                type = "response") 
  
  pred$test$init <- predict.glm(object = models$glm_init, 
                                newdata = df$test , 
                                type = "response") 
  
  # Init data for boosting algorithm 
  
  boosting_df$train <- data.frame(df$train, init_pred = pred$train$init )
  boosting_df$cal <- data.frame(df$cal, init_pred = pred$cal$init )
  boosting_df$test <- data.frame(df$test, init_pred = pred$test$init )
  
  # ======================================================================
  ## Reference model: Raw GBM 
  # ======================================================================
  
  # GBM 
  models$raw_gbm <- gbm(model.freq_gbm.ref, 
                  data = boosting_df$train, 
                  distribution = "poisson",
                  n.trees = n_trees_mu,
                  n.minobsinnode = 10,
                  interaction.depth = tree_depth_mu,
                  shrinkage = learning_rate_mu,
                  cv.folds = 5
  )
  
  models$raw_gbm.ntrees <- gbm.perf(models$raw_gbm, method = "cv")      
  
  pred$train$ref <- predict.gbm(object = models$raw_gbm, 
                                n.trees=models$raw_gbm.ntrees, 
                                newdata = boosting_df$train , 
                                type = "response") *boosting_df$train$dur
  
  balance_factor <- mean(boosting_df$train$freq)/mean(pred$train$ref)
  
  pred$train$ref <-  pred$train$ref*balance_factor
  
  pred$test$ref <- predict.gbm(object = models$raw_gbm,
                              n.trees=models$raw_gbm.ntrees,
                              newdata = boosting_df$test , 
                              type = "response")  *boosting_df$test$dur * balance_factor
  
  
  pred$cal$ref <- predict.gbm(object = models$raw_gbm,
                               n.trees=models$raw_gbm.ntrees,
                               newdata = boosting_df$cal , 
                               type = "response")  *boosting_df$cal$dur * balance_factor
  
  # ======================================================================
  ## Training boosting GBM ##
  # ======================================================================
  
  # GBM 
  models$gbm_boost <- gbm(model.freq_gbm.boost, 
                  data = boosting_df$train, 
                  distribution = "poisson",
                  n.trees = n_trees_mu,
                  n.minobsinnode = 10,
                  interaction.depth = tree_depth_mu,
                  shrinkage = learning_rate_mu,
                  cv.folds = 5
  )
  
  models$gbm_boost.ntrees <- gbm.perf(models$gbm_boost , method = "cv")      
  
  pred$train$boost <- predict.gbm(object = models$gbm_boost,n.trees=models$gbm_boost.ntrees, newdata = boosting_df$train , type = "response") *boosting_df$train$init_pred
  balance_factor <- mean(boosting_df$train$freq)/mean(pred$train$boost)
  pred$train$boost <- pred$train$boost*balance_factor
  pred$test$boost <- predict.gbm(object = models$gbm_boost,n.trees=models$gbm_boost.ntrees, newdata = boosting_df$test , type = "response")  *boosting_df$test$init_pred * balance_factor
  pred$cal$boost <- predict.gbm(object = models$gbm_boost,n.trees=models$gbm_boost.ntrees, newdata = boosting_df$cal , type = "response")  *boosting_df$cal$init_pred * balance_factor
  
  
  boosting_df$train <- data.frame(df$train, init_pred = pred$train$init , boost_pred = pred$train$boost )
  boosting_df$cal <- data.frame(df$cal, init_pred = pred$cal$init , boost_pred = pred$cal$boost )
  boosting_df$test <- data.frame(df$test, init_pred = pred$test$init , boost_pred = pred$test$boost )
  
  # Balance checks
  assert( round(mean(boosting_df$train$boost_pred),4) == round(mean(boosting_df$train$init_pred),4) )
  
  
  if (save == TRUE){
    save(models, file = paste("Data/Models_",suffix,".RData", sep = ""))
    save(boosting_df, file = paste("Data/Boost_data_",suffix,".RData", sep = ""))
    save(pred, file = paste("Data/Predictions_",suffix,".RData", sep = ""))
  }
}else{

    load(paste("Data/Models_",suffix,".RData", sep = ""))
    load(paste("Data/Boost_data_",suffix,".RData", sep = ""))
    load(paste("Data/Predictions_",suffix,".RData", sep = ""))
}

# ======================================================================
                    ## Extracting boosting factors ##
# ======================================================================
if (new_univar_effects == TRUE){
  # Marginal (univariate) effects -------------------------------------------
  
  # PDP-functions 
  pgbm <- function(object, newdata){
    mean(exp(predict.gbm(object, newdata = newdata)))
  }
  pgbm_raw <- function(object, newdata){
    mean(exp(predict.gbm(object, newdata = newdata))*newdata[,"dur"])
  }
  pglm <- function(object, newdata){
    mean(predict.glm(object, newdata = newdata, type="response"))
  }
  
  univariate_pdp_data <- list()
  
  for (fact in num_facts){
    if (is.factor(df$train[,fact]) == FALSE){ 
      
      
      xlim <- quantile(df$train[,fact], c(.01,.99)) 
      
      p1 <- partial(models$gbm_boost, pred.fun=pgbm, pred.var = c(fact), n.trees= models$gbm_boost.ntrees,recursive = FALSE) 
      p2 <- partial(models$glm_init, pred.fun=pglm, pred.var = c(fact))
      p3 <- partial(models$raw_gbm, pred.fun=pgbm_raw, pred.var = c(fact), n.trees= models$raw_gbm.ntrees,recursive = FALSE)
      p4 <- p1$yhat*p2$yhat
      
      
      indx_plt <- which(p1[,fact] > xlim[1] & p1[,fact] < xlim[2])
      scale_factor_boosting <- mean(df$train$freq) 
      
      univariate_pdp_data[[fact]] <- data.frame(factor_val = p1[,1], 
                                                Tariff = p2$yhat[], 
                                                Boost = p1$yhat[], 
                                                Ref_gbm = p3$yhat[], 
                                                After_boost = p4[])
      
      
      if (plot_during_algo ==TRUE){
      
        univariate_pdp_data[[fact]] %>% 
          ggplot(aes(x=factor_val)) + 
          geom_line(aes(y=Tariff, color="black")) +
          geom_line(aes(y=Boost*mean(df$train$freq), color="red"))+
          geom_line(aes(y=Ref_gbm, color="grey"), lty=2)+
          geom_line(aes(y=After_boost, color="blue"))+
          geom_abline(intercept = mean(df$train$freq),slope=0, color="grey", alpha=0.5)+
          xlim(xlim[1],xlim[2])+
          labs(x= fact,
               y="PDP",
               subtitle="Bosting factor (red) correspond to the multiplicative difference (according to PDP) 
               between original tariff (black) and boosted tariff (blue)")+
          scale_colour_manual(name = 'Model', 
                              values =c('black'='black','red'='red','grey'='grey','blue'='blue'), 
                              labels = c('Tariff (GLM)','Boosted tariff', 'Reference (pure GBM)', 'Boosting factor'))+
          scale_y_continuous(sec.axis = sec_axis( trans=~./mean(df$train$freq), name="Boosting factor"))+
          theme_classic()  +
          ggsave(paste(plot_folder,"/PDP_boost_",fact , ".png",sep=""))
        
      }
        
    }
  }
  
  
  if (save == TRUE){
    save(univariate_pdp_data, file = paste("Data/Univar_effects_",suffix,".RData", sep = ""))
  }
}else{
  
  
  load(paste("Data/Univar_effects_",suffix,".RData", sep = ""))
  
}

# Testing boosting factors  -----------------------------------------------

### OBSOBS: Hanterar endast - numeriska - linj�ra ursprungliga faktorer (m�ste hantera godtyckligt definierad faktor sedermera!)

# INIT


min_improvement <- 1


loss_diff <- data.frame(facts = num_facts, diff = rep(NA, length(num_facts)) )

num_facts_loop <- num_facts
final_factors <- list()
final_update <- list()
fact_selected <- list()
loss_improvements <- list()

# Test data predictions
test_pred_start <- predict.glm(object = models$glm_init, 
                               newdata = boosting_df$test , 
                               type = "response") 

cal_pred_start <- predict.glm(object = models$glm_init, 
                                newdata = boosting_df$cal , 
                                type = "response") 

train_pred_start <- predict.glm(object = models$glm_init, 
                               newdata = boosting_df$train , 
                               type = "response") 




for (k in 1:length(num_facts)){
  factor_update <- list()
  old_factor_effect <- list()
  train_pred_new <- list()
  cal_pred_new <- list()
  test_pred_new <- list()
  balance_factor <- list()
  new_factor <- list()
  
  if (k > 1){  
    num_facts_loop <- num_facts_loop[!(num_facts_loop %in% fact_selected )] 
  }
  
  
  loss_diff <- data.frame(facts = num_facts_loop, diff = rep(NA, length(num_facts_loop)) )
  
  for (fact in num_facts_loop){
    
    # Factor range
    range <- min(df$all[fact]):max(df$all[fact])
    
    univariate_pdp_data[[fact]]$factor_val <- round(univariate_pdp_data[[fact]]$factor_val) # OBS: Hanterar endast factorer med niv�er n�ra heltal!
    
    
    old_factor_effect[[fact]] <- exp(models$glm_init$coefficients[fact]*range) 
    factor_update[[fact]] <-  as.numeric( approx(univariate_pdp_data[[fact]]$factor_val , univariate_pdp_data[[fact]]$Boost , xout=range)[["y"]])
    factor_update[[fact]][is.na(factor_update[[fact]])] <- 1
    
    new_factor[[fact]] <- old_factor_effect[[fact]] * factor_update[[fact]]
    
    #  Updating predictions with new effect
    train_pred_new[[fact]] <- (train_pred_start * factor_update[[fact]][boosting_df$train[[fact]]  - min(range)+1 ] )
    balance_factor[[fact]] <- mean(boosting_df$train$freq)/mean(train_pred_new[[fact]])
    train_pred_new[[fact]] <- train_pred_new[[fact]] * balance_factor[[fact]]
    
    cal_pred_new[[fact]] <- (cal_pred_start * factor_update[[fact]][boosting_df$cal[[fact]]  - min(range)+1 ] )*balance_factor[[fact]]
    test_pred_new[[fact]] <- (test_pred_start * factor_update[[fact]][boosting_df$test[[fact]]  - min(range)+1 ] )*balance_factor[[fact]]
    
    
    # Evaluate 
    loss_start <- deviance(pred_mu = cal_pred_start, y =boosting_df$cal$freq, res=FALSE )
    loss_new <- deviance(pred_mu = cal_pred_new[[fact]], y =boosting_df$cal$freq, res=FALSE )
    
    loss_diff[which(loss_diff$facts==fact), "diff"] <- loss_new - loss_start
  
  }
  
  
  # Include according to best prediction 
  
  if ( 1 + min(loss_diff$diff)/loss_start < min_improvement){
    loss_improvements[[k]] <- min(loss_diff$diff) 
    fact_selected[[k]] <- loss_diff$facts[which(loss_diff$diff == min(loss_diff$diff))]
    
    
    # Updating factor
    final_factors[[fact_selected[[k]]]] <- new_factor[[fact_selected[[k]]]]
    final_update[[fact]] <- factor_update[[fact]]
    
    
    # Updating predictions
    train_pred_start <- train_pred_new[[fact_selected[[k]]]]
    cal_pred_start <- cal_pred_new[[fact_selected[[k]]]]
    test_pred_start <- test_pred_new[[fact_selected[[k]]]]
    
    
    
  }else{
    
    # Predictions after final univariate boosting
    
    pred$train$univar_boosted <- train_pred_start 
    pred$cal$univar_boosted <- cal_pred_start 
    pred$test$univar_boosted <- test_pred_start 
    
    print("Predictive performance exhausted. Breaking...")
    break
  }
}



## TO DO:
# Make algo data-independent (i.e. scalable)
# Cross validation - How?
 

# Updated model factors
for (fact in names(final_factors)){
univariate_pdp_data[[fact]] %>% 
  ggplot(aes(x=factor_val))+
  geom_line(aes(y=Tariff, color="black")) + 
  geom_line(aes(y=Boost*mean(df$train$freq), color="red"))+
  geom_line(aes(y=Ref_gbm, color="grey"), lty=2) +
  geom_line(aes(y=After_boost, color="blue")) +
  geom_abline(intercept = mean(df$train$freq),slope=0, color="grey", alpha=0.5)+
  #xlim(xlim[1],xlim[2])+
  labs(x= fact,
       y="PDP" )+
  scale_colour_manual(name = '', 
                      values =c('black'='black','red'='red','grey'='grey','blue'='blue'), 
                      labels = c('Benchmark','Boosted GLM', 'Reference (GBM)', 'Boosting factor'))+
  scale_y_continuous(sec.axis = sec_axis( trans=~./mean(df$train$freq), name="Boosting factor")) + 
  theme_classic() +
    theme(legend.position ="bottom")+
    ggsave(paste(plot_folder,"/PDP_boost_",fact , ".png",sep=""))
}

# Predictive performance --------------------------------------------------

MSEP_cal <- data.frame( Model=c("Reference", "Boosted", "Init-tariff", "Univar_boosted_GLM"),
                         
                         
                         MSEP=round(c( mean((pred$cal$ref - boosting_df$cal$freq) ^2), 
                                 mean((pred$cal$boost - boosting_df$cal$freq) ^2),
                                 mean((pred$cal$init - boosting_df$cal$freq) ^2),
                                 mean((pred$cal$univar_boosted - boosting_df$cal$freq) ^2)),6),
                         
                         Deviance = round(c(deviance(pred$cal$ref, pred_phi=NULL, boosting_df$cal$freq, res = FALSE),
                                      deviance(pred$cal$boost, pred_phi=NULL, boosting_df$cal$freq, res = FALSE),
                                      deviance(pred$cal$init, pred_phi=NULL, boosting_df$cal$freq, res = FALSE),
                                      deviance(pred$cal$univar_boosted, pred_phi=NULL, boosting_df$cal$freq, res = FALSE))
                         )
)


MSEP_test <- data.frame( Model=c("Reference", "Boosted", "Init-tariff", "Univar_boosted_GLM"),
                    
                    
                    MSEP=round(c( mean((pred$test$ref - boosting_df$test$freq) ^2), 
                            mean((pred$test$boost - boosting_df$test$freq) ^2),
                            mean((pred$test$init - boosting_df$test$freq) ^2),
                            mean((pred$test$univar_boosted - boosting_df$test$freq) ^2)),6),
                    
                    Deviance = round(c(deviance(pred$test$ref, pred_phi=NULL, boosting_df$test$freq, res = FALSE),
                                 deviance(pred$test$boost, pred_phi=NULL, boosting_df$test$freq, res = FALSE),
                                 deviance(pred$test$init, pred_phi=NULL, boosting_df$test$freq, res = FALSE),
                                 deviance(pred$test$univar_boosted, pred_phi=NULL, boosting_df$test$freq, res = FALSE))
                    )
                    )
 
 

p_true_nu_mse_values <- ggplot(tibble(x=0,y=0, tb=list(MSEP_test ))) +
  theme_void() + 
  geom_table(aes(x, y, label = tb),parse = TRUE)  +
  ggsave(paste(plot_folder,"/Model_evaluation_test.png",sep=""), width=5, height=1.5)   

# All predictions

pred_data <- data.frame(model="1.Initial tariff", pred = pred$test$init,dur =  boosting_df$test$dur, obs= boosting_df$test$freq) %>%
  bind_rows(  data.frame(model="2.Boosted GLM", pred = pred$test$univar_boosted,dur =  boosting_df$test$dur, obs= boosting_df$test$freq))%>%
  bind_rows(  data.frame(model="3.GBM", pred = pred$test$ref,dur =  boosting_df$test$dur, obs= boosting_df$test$freq))%>%
  bind_rows(  data.frame(model="4.Boosted (GBM) tariff", pred = pred$test$boost,dur =  boosting_df$test$dur, obs= boosting_df$test$freq))
 

# MU
pred_data %>% 
  group_by(model) %>%
  arrange(pred, .by_group = TRUE) %>%
  mutate(bin = ceiling( (cumsum(dur)/sum(dur)*1000) )) %>%
  group_by(model,bin) %>%
  summarise(
    pred  = mean(pred),
    obs = mean(obs)
  ) %>%
  ggplot(aes(x=bin)) + 
  geom_point(aes(y=obs)) +  
  geom_line(aes(y=pred), size=1, colour="red" ) +
  theme_classic() +
  facet_grid(model ~. )+
  ggsave(paste(plot_folder,"/Predictions.png",sep=""), dpi = 300)


# Game 

game_data <- data.frame(init= pred$test$init, 
                        boosted =  pred$test$univar_boosted,
                        boosted_gbm = pred$test$boost,
                        ref_gbm = pred$test$ref,
                        dur =  boosting_df$test$dur,
                        obs =   boosting_df$test$freq
                        )
                        
                        
game_data %>% mutate(premium_boosted = cumsum(boosted*(boosted < ref_gbm)),
                     profit_boosted = cumsum((boosted - obs)*(boosted < ref_gbm)),
                     premium_ref = cumsum(ref_gbm*(boosted > ref_gbm)),
                     profit_ref = cumsum((ref_gbm - obs)*(boosted > ref_gbm)),
                     id=row_number()/n())     %>%
  
  ggplot(aes(x=id))+
  geom_line(aes(y=profit_boosted, colour="blue") )+
  geom_line(aes(y=profit_ref, colour="red") )+
  theme_classic()+
  theme(legend.position = c(.8, .5))+
  labs(
        y="Profit (accumulated)",
        x="% of portfolio (lowest to highest risk)", color="",shape="" ) +
  scale_colour_manual(name = 'model', 
                      values =c('red'='red','blue'='blue'), 
                      labels = c('Boosted tariff', 'Ref tariff (pure GBM)'))+
  ggsave(paste(plot_folder,"/Game_boosted_vs_ref.png",sep=""), dpi = 300)
                        
                        


game_data %>% mutate(premium_boosted = cumsum(init*(init < ref_gbm)),
                     profit_boosted = cumsum((init - obs)*(init < ref_gbm)),
                     premium_ref = cumsum(ref_gbm*(init > ref_gbm)),
                     profit_ref = cumsum((ref_gbm - obs)*(init > ref_gbm)),
                     id=row_number()/n())     %>%
  
  ggplot(aes(x=id))+
  geom_line(aes(y=profit_boosted, colour="blue") )+
  geom_line(aes(y=profit_ref, colour="red") )+
  theme_classic()+
  theme(legend.position = c(.8, .5))+
  labs( 
        y="Profit (accumulated)",
        x="% of portfolio (lowest to highest risk)", color="",shape="" ) +
  scale_colour_manual(name = 'model', 
                      values =c('red'='red','blue'='blue'), 
                      labels = c('Init tariff', 'Ref tariff (pure GBM)'))+
  ggsave(paste(plot_folder,"/Game_init_vs_ref.png",sep=""), dpi = 300)





game_data %>% mutate(premium_boosted = cumsum(boosted*(boosted < init)),
                     profit_boosted = cumsum((boosted - obs)*(boosted < init)),
                     premium_init = cumsum(init*(boosted > init)),
                     profit_init = cumsum((init - obs)*(boosted > init)),
                     id=row_number()/n())     %>%
  
  ggplot(aes(x=id)) +
  geom_line(aes(y=profit_boosted, colour="red"))+
  geom_line(aes(y=profit_init, colour="blue"))+
  theme_classic()+
  theme(legend.position = c(.8, .5))+
  labs(
        y="Profit (accumulated)",
        x="% of portfolio (lowest to highest risk)", color="",shape="" ) +
  scale_colour_manual(name = 'model', 
                      values =c('red'='red','blue'='blue'), 
                      labels = c('Benchmark model', 'Boosted GLM'))+
  ggsave(paste(plot_folder,"/Game_boosted_vs_init.png",sep=""), dpi = 300)




t <- game_data %>% mutate(premium_boosted = cumsum(boosted*(boosted < init)),
                     profit_boosted = cumsum((boosted - obs)*(boosted < init)),
                     premium_init = cumsum(init*(boosted > init)),
                     profit_init = cumsum((init - obs)*(boosted > init)),
                     id=row_number()/n())   

max(t$premium_init)

 